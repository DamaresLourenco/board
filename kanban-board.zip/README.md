# 🗂️ Kanban Board

Um quadro Kanban simples e funcional, inspirado no projeto da DIO, com melhorias como drag-and-drop, tema escuro e salvamento local das tarefas.

## 🚀 Funcionalidades
- Criar tarefas
- Mover entre colunas
- Excluir tarefas
- Salvar no navegador (localStorage)
- Tema claro/escuro

## 📦 Tecnologias
- HTML, CSS e JavaScript puro

## 📱 Responsivo
Funciona no computador, tablet e celular.

## 📷 Preview
![screenshot](preview.png)

## 🧪 Como rodar localmente
1. Baixe os arquivos
2. Abra `index.html` em seu navegador

## 🔗 Deploy
Veja publicado no GitHub Pages:  
[https://seu-usuario.github.io/kanban-board/](https://seu-usuario.github.io/kanban-board/)
